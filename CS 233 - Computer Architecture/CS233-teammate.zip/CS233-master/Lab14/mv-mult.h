#ifndef MV_MULT
#define MV_MULT

#define SIZE 32
#define ITER 1000000

float *mv_mult_vector(float mat[SIZE][SIZE], float vec[SIZE]);

#endif
