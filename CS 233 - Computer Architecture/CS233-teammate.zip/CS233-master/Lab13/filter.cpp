#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include "filter.h"
using std::max;

// modify this code by fusing loops together
void
filter_fusion(pixel_t **image1, pixel_t **image2) {
    filter1(image1, image2, 1);
    filter1(image1, image2, 2);
    filter1(image1, image2, 3);
    filter1(image1, image2, 4);
    filter1(image1, image2, 5);
    for (int i = 6; i < SIZE - 1; i ++) {
        filter1(image1, image2, i);
        filter2(image1, image2, i-4);
        filter3(image2, i-5);
    }
    filter2(image1, image2, SIZE-5);
    filter2(image1, image2, SIZE-4);
    filter2(image1, image2, SIZE-3);
    filter3(image2, SIZE-6);
}

// modify this code by adding software prefetching
void
filter_prefetch(pixel_t **image1, pixel_t **image2) {
    for (int i = 1; i < SIZE - 1; i ++) {
        __builtin_prefetch(image2[i], 1, 3);
        __builtin_prefetch(image2[i+1], 1, 3);
        __builtin_prefetch(image2[i+2], 1, 3);
        __builtin_prefetch(image1[i], 0, 3);
        __builtin_prefetch(image1[i+1], 0, 3);
        __builtin_prefetch(image1[i+2], 0, 3);

        filter1(image1, image2, i);
        // if(i%5==1)
        //   for(int j=0; j<max(5, SIZE-i-1); j++)
        //   {
        //     __builtin_prefetch(image2[i+j], 1, 3);
        //     __builtin_prefetch(image1[i+j+1], 0, 3);
        //   }
    }

    for (int i = 2; i < SIZE - 2; i ++) {
        __builtin_prefetch(image2[i], 1, 3);
        __builtin_prefetch(image2[i+1], 1, 3);
        __builtin_prefetch(image2[i+2], 1, 3);
        __builtin_prefetch(image2[i+3], 1, 3);
        __builtin_prefetch(image1[i], 0, 3);
        __builtin_prefetch(image1[i+1], 0, 3);
        __builtin_prefetch(image1[i+2], 0, 3);
        __builtin_prefetch(image1[i+3], 0, 3);
        filter2(image1, image2, i);
        // if(i%5==2)
        //   for(int j=0; j<max(5, SIZE-i-2); j++)
        //   {
        //     __builtin_prefetch(image2[i+j], 1, 3);
        //     __builtin_prefetch(image1[i+j+2], 0, 3);
        //   }
    }

    for (int i = 1; i < SIZE - 5; i ++) {
        __builtin_prefetch(image2[i], 1, 3);
        __builtin_prefetch(image2[i+1], 1, 3);
        __builtin_prefetch(image2[i+2], 1, 3);
        __builtin_prefetch(image2[i+3], 1, 3);
        __builtin_prefetch(image2[i+4], 1, 3);
        __builtin_prefetch(image2[i+5], 1, 3);
        filter3(image2, i);
        // if(i%5==1)
        //   for(int j=0; j<max(5, SIZE-i); j++)
        //   {
        //     __builtin_prefetch(image2[i+j]);
        //   }
    }
}

// modify this code by adding software prefetching and fusing loops together
void
filter_all(pixel_t **image1, pixel_t **image2) {
    __builtin_prefetch(image2[1], 1, 3);
    __builtin_prefetch(image2[2], 1, 3);
    __builtin_prefetch(image2[3], 1, 3);
    __builtin_prefetch(image2[4], 1, 3);
    __builtin_prefetch(image2[5], 1, 3);
    __builtin_prefetch(image1[0], 0, 3);
    __builtin_prefetch(image1[1], 0, 3);
    __builtin_prefetch(image1[2], 0, 3);
    __builtin_prefetch(image1[3], 0, 3);
    __builtin_prefetch(image1[4], 0, 3);
    __builtin_prefetch(image1[5], 0, 3);
    __builtin_prefetch(image1[6], 0, 3);
    filter1(image1, image2, 1);
    filter1(image1, image2, 2);
    filter1(image1, image2, 3);
    filter1(image1, image2, 4);
    filter1(image1, image2, 5);
    for (int i = 6; i < SIZE - 1; i ++) {
        __builtin_prefetch(image2[i], 1, 3);
        __builtin_prefetch(image2[i+1], 1, 3);
        __builtin_prefetch(image1[i], 0, 3);
        __builtin_prefetch(image1[i+1], 0, 3);
        __builtin_prefetch(image1[i+2], 0, 3);
        __builtin_prefetch(image1[i+3], 0, 3);
        filter1(image1, image2, i);
        filter2(image1, image2, i-4);
        filter3(image2, i-5);
    }
    filter2(image1, image2, SIZE-5);
    filter2(image1, image2, SIZE-4);
    filter2(image1, image2, SIZE-3);
    filter3(image2, SIZE-6);
}
