#include "cacheblock.h"

uint32_t Cache::Block::get_address() const {
  return ((_tag<<_cache_config.get_num_index_bits())+_index)<<_cache_config.get_num_block_offset_bits();
}
