/**
 * @file
 * Contains the implementation of the extractMessage function.
 */

#include <iostream> // might be useful for debugging
#include <assert.h>
#include "extractMessage.h"

using namespace std;

char *extractMessage(const char *message_in, int length) {
   // length must be a multiple of 8
   assert((length % 8) == 0);

   // allocate an array for the output
   char *message_out = new char[length];
   bool ** bits = new bool*[8];
   for(int i=0; i<8; i++)
      bits[i]=new bool[8];

	for(int i=0; i<length/8; i++)
  {
    for(int j=0; j<8; j++)
    {
      for(int k=0; k<8; k++)
      {
        bits[k][j]=((message_in[i*8+j] | 0x00) >> k ) & 0x01 ;
      }
    }

    for(int j=0; j<8; j++)
    {
      int temp=0;
      for(int k=0; k<8; k++)
      {
        temp = temp | (bits[j][k] << k);
      }
      message_out[i*8+j]=(char)temp;
    }
  }

	return message_out;
}
