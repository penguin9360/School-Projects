/**
 * @file
 * Contains the implementation of the countOnes function.
 */
unsigned countOnes(unsigned input) {
		unsigned left=0, right=0;

		right=input & 0x55555555;
		left=input & 0xAAAAAAAA;
		input=(left >> 1) + right;

		right=input & 0x33333333;
		left=input & 0xCCCCCCCC;
		input=(left >> 2) + right;

		right=input & 0x0F0F0F0F;
		left=input & 0xF0F0F0F0;
		input=(left >> 4) + right;

		right=input & 0x00FF00FF00FF;
		left=input & 0xFF00FF00FF00;
		input=(left >> 8) + right;

		left=input >> 16;
		right=input << 16 >> 16;
		input=left + right;

		return input;
}
