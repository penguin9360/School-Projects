// a code generator for the ALU chain in the 32-bit ALU
// see example_generator.cpp for inspiration

#include <cstdio>
using std::printf;

int
main()
{
    int width = 32;
    for (int i = 0 ; i < width ; i++)
    {
        printf("    alu1 a%d(out[%d], chain[%d], A[%d], B[%d], chain[%d], control);\n", i, i, i+1, i, i, i);
    }
}

// make generator
// ./generator
