#include "simplecache.h"

int SimpleCache::find(int index, int tag, int block_offset) {
  for(auto it = _cache[index].begin(); it != _cache[index].end(); it++)
    if( it->tag()==tag && it->valid())
      return it->get_byte(block_offset);
  return 0xdeadbeef;
}

void SimpleCache::insert(int index, int tag, char data[]) {
  for(auto it = _cache[index].begin(); it != _cache[index].end(); it++)
    if(!it->valid())
    {
      it->replace(tag, data);
      return;
    }
  auto it = _cache[index].begin();
  it->replace(tag, data);
}
